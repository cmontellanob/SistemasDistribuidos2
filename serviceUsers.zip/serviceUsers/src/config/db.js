var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/bd_usuarios');
//mongoose.connect('mongodb://joraca:123456@ds215370.mlab.com:15370/user_75');