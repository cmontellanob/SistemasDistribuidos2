// config.js
module.exports = {
    'secret': 'sup6546ersecreto'
};